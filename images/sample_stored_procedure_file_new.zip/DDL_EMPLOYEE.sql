-- 직원 테이블
CREATE TABLE TPJ_EMPLOYEE (
    EMP_KEY     VARCHAR2(10) PRIMARY KEY,  -- 직원키
    EMP_NAME    VARCHAR2(50) NOT NULL,     -- 직원명
    DEPT_CODE   VARCHAR2(10) NOT NULL,      -- 부서코드
    REGULAR_YN  CHAR(1) NOT NULL          -- 정직원여부(Y/N)
);
