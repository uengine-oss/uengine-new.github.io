package kr.hanbit.delivery.order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Map;

import kr.hanbit.delivery.db.Db;

/**
 * Order processing. Statuses: WAITING (waiting for acceptance) → ACCEPTED (accepted) → COOKING (cooking) → DELIVERING → DELIVERED.
 * Before acceptance, the customer can end an order as CANCELLED, or the store owner as REJECTED.
 */
public class OrderService {

    /**
     * Place an order. The store must be open, and if even one menu item is sold out, the whole order is refused.
     * menu.price at order time is copied into order_item.unit_price (it stays the same even if the price changes later).
     */
    public String placeOrder(String customerId, String storeId, Map<String, Integer> menuQty) throws SQLException {
        if (menuQty == null || menuQty.isEmpty()) throw new IllegalArgumentException("No menu items to order");
        try (Connection con = Db.open()) {
            try (PreparedStatement st = con.prepareStatement("SELECT is_open FROM store WHERE store_id = ?")) {
                st.setString(1, storeId);
                ResultSet rs = st.executeQuery();
                if (!rs.next() || !rs.getBoolean(1)) throw new IllegalStateException("The store is not open");
            }
            String orderId = "O" + System.currentTimeMillis() % 100000000000L;
            int total = 0;
            try (PreparedStatement menu = con.prepareStatement(
                         "SELECT price, sold_out FROM menu WHERE menu_id = ? AND store_id = ?");
                 PreparedStatement item = con.prepareStatement(
                         "INSERT INTO order_item (order_id, menu_id, qty, unit_price) VALUES (?, ?, ?, ?)")) {
                for (Map.Entry<String, Integer> e : menuQty.entrySet()) {
                    if (e.getValue() == null || e.getValue() <= 0) throw new IllegalArgumentException("Quantity must be at least 1");
                    menu.setString(1, e.getKey());
                    menu.setString(2, storeId);
                    ResultSet m = menu.executeQuery();
                    if (!m.next()) throw new IllegalArgumentException("Not a menu item of this store: " + e.getKey());
                    if (m.getBoolean("sold_out")) throw new IllegalStateException("A menu item is sold out: " + e.getKey());
                    int price = m.getInt("price");
                    total += price * e.getValue();
                    item.setString(1, orderId);
                    item.setString(2, e.getKey());
                    item.setInt(3, e.getValue());
                    item.setInt(4, price);
                    item.addBatch();
                }
                try (PreparedStatement ord = con.prepareStatement(
                        "INSERT INTO orders (order_id, customer_id, store_id, status, total_price, ordered_at) VALUES (?, ?, ?, 'WAITING', ?, ?)")) {
                    ord.setString(1, orderId);
                    ord.setString(2, customerId);
                    ord.setString(3, storeId);
                    ord.setInt(4, total);
                    ord.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
                    ord.executeUpdate();
                }
                item.executeBatch();
            }
            con.commit();
            return orderId;
        }
    }

    /** Store owner accepts. Only orders waiting for acceptance (WAITING). If the customer cancels at the same time, only one succeeds (conditional UPDATE). */
    public void acceptOrder(String storeId, String orderId) throws SQLException {
        changeStatus(storeId, orderId, "WAITING", "ACCEPTED", "Only waiting orders can be accepted");
    }

    /** Store owner rejects (out of ingredients, etc.). No reason is recorded — the customer is told by phone. */
    public void rejectOrder(String storeId, String orderId) throws SQLException {
        changeStatus(storeId, orderId, "WAITING", "REJECTED", "Only waiting orders can be rejected");
    }

    /** Start cooking. */
    public void startCooking(String storeId, String orderId) throws SQLException {
        changeStatus(storeId, orderId, "ACCEPTED", "COOKING", "Cooking can only start on accepted orders");
    }

    /** Customer cancels. Only their own order, and only while it is not yet accepted (WAITING). */
    public void cancelOrder(String customerId, String orderId) throws SQLException {
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE orders SET status = 'CANCELLED' WHERE order_id = ? AND customer_id = ? AND status = 'WAITING'")) {
            ps.setString(1, orderId);
            ps.setString(2, customerId);
            if (ps.executeUpdate() == 0) throw new IllegalStateException("An order that has already been accepted cannot be cancelled");
            con.commit();
        }
    }

    private void changeStatus(String storeId, String orderId, String from, String to, String message) throws SQLException {
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE orders SET status = ? WHERE order_id = ? AND store_id = ? AND status = ?")) {
            ps.setString(1, to);
            ps.setString(2, orderId);
            ps.setString(3, storeId);
            ps.setString(4, from);
            if (ps.executeUpdate() == 0) throw new IllegalStateException(message);
            con.commit();
        }
    }
}
