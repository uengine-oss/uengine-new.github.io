package kr.hanbit.delivery.delivery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import kr.hanbit.delivery.db.Db;

/** Delivery — rider assignment, pickup, delivery completion. */
public class DeliveryService {

    /** Assigns a rider to an order being cooked (COOKING) and changes it to out for delivery (DELIVERING). One delivery per order. */
    public String dispatch(String orderId, String riderId) throws SQLException {
        try (Connection con = Db.open()) {
            try (PreparedStatement chk = con.prepareStatement("SELECT 1 FROM delivery WHERE order_id = ?")) {
                chk.setString(1, orderId);
                if (chk.executeQuery().next()) throw new IllegalStateException("A delivery is already assigned to this order");
            }
            try (PreparedStatement up = con.prepareStatement(
                    "UPDATE orders SET status = 'DELIVERING' WHERE order_id = ? AND status = 'COOKING'")) {
                up.setString(1, orderId);
                if (up.executeUpdate() == 0) throw new IllegalStateException("Only orders being cooked can be dispatched");
            }
            String deliveryId = "D" + System.currentTimeMillis() % 100000000000L;
            try (PreparedStatement ins = con.prepareStatement(
                    "INSERT INTO delivery (delivery_id, order_id, rider_id) VALUES (?, ?, ?)")) {
                ins.setString(1, deliveryId);
                ins.setString(2, orderId);
                ins.setString(3, riderId);
                ins.executeUpdate();
            }
            con.commit();
            return deliveryId;
        }
    }

    /** The rider collects the food at the store. */
    public void pickUp(String deliveryId, String riderId) throws SQLException {
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE delivery SET picked_up_at = ? WHERE delivery_id = ? AND rider_id = ? AND picked_up_at IS NULL")) {
            ps.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
            ps.setString(2, deliveryId);
            ps.setString(3, riderId);
            if (ps.executeUpdate() == 0) throw new IllegalStateException("Not the assigned rider, or already picked up");
            con.commit();
        }
    }

    /** Delivery completed — only picked-up deliveries. The order becomes DELIVERED too. */
    public void complete(String deliveryId, String riderId) throws SQLException {
        try (Connection con = Db.open()) {
            String orderId;
            try (PreparedStatement q = con.prepareStatement(
                    "SELECT order_id FROM delivery WHERE delivery_id = ? AND rider_id = ? AND picked_up_at IS NOT NULL AND delivered_at IS NULL")) {
                q.setString(1, deliveryId);
                q.setString(2, riderId);
                ResultSet rs = q.executeQuery();
                if (!rs.next()) throw new IllegalStateException("Delivery not picked up yet, or already completed");
                orderId = rs.getString(1);
            }
            try (PreparedStatement d = con.prepareStatement("UPDATE delivery SET delivered_at = ? WHERE delivery_id = ?");
                 PreparedStatement o = con.prepareStatement("UPDATE orders SET status = 'DELIVERED' WHERE order_id = ?")) {
                d.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
                d.setString(2, deliveryId);
                d.executeUpdate();
                o.setString(1, orderId);
                o.executeUpdate();
            }
            con.commit();
        }
    }
}
