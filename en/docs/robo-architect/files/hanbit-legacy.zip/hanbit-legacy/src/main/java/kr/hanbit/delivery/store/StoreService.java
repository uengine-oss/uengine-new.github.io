package kr.hanbit.delivery.store;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import kr.hanbit.delivery.db.Db;

/** Whether a store is open for business. */
public class StoreService {

    public void open(String storeId) throws SQLException {
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement("UPDATE store SET is_open = true WHERE store_id = ?")) {
            ps.setString(1, storeId);
            ps.executeUpdate();
            con.commit();
        }
    }

    /** Close for the day. Every order not yet accepted (WAITING) is ended as rejected (REJECTED). */
    public int close(String storeId) throws SQLException {
        try (Connection con = Db.open();
             PreparedStatement st = con.prepareStatement("UPDATE store SET is_open = false WHERE store_id = ?");
             PreparedStatement rej = con.prepareStatement(
                     "UPDATE orders SET status = 'REJECTED' WHERE store_id = ? AND status = 'WAITING'")) {
            st.setString(1, storeId);
            st.executeUpdate();
            rej.setString(1, storeId);
            int rejected = rej.executeUpdate();
            con.commit();
            return rejected;
        }
    }
}
