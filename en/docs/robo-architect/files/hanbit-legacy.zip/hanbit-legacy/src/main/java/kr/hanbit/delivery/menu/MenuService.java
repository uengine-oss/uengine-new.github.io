package kr.hanbit.delivery.menu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import kr.hanbit.delivery.db.Db;

/** The store owner's menu management — register, change price, mark as sold out. */
public class MenuService {

    /** Register a menu item. The price must be greater than 0, and a store cannot have two menu items with the same name. */
    public String registerMenu(String storeId, String menuName, int price) throws SQLException {
        if (menuName == null || menuName.trim().isEmpty()) throw new IllegalArgumentException("Menu name is empty");
        if (price <= 0) throw new IllegalArgumentException("Price must be greater than 0");
        try (Connection con = Db.open()) {
            try (PreparedStatement dup = con.prepareStatement(
                    "SELECT 1 FROM menu WHERE store_id = ? AND menu_name = ?")) {
                dup.setString(1, storeId);
                dup.setString(2, menuName.trim());
                if (dup.executeQuery().next()) throw new IllegalStateException("A menu item with this name already exists");
            }
            String menuId = "M" + System.currentTimeMillis() % 100000000;
            try (PreparedStatement ins = con.prepareStatement(
                    "INSERT INTO menu (menu_id, store_id, menu_name, price, sold_out) VALUES (?, ?, ?, ?, false)")) {
                ins.setString(1, menuId);
                ins.setString(2, storeId);
                ins.setString(3, menuName.trim());
                ins.setInt(4, price);
                ins.executeUpdate();
            }
            con.commit();
            return menuId;
        }
    }

    /** Change the price. Orders already received keep their amount in order_item.unit_price, so it does not change. */
    public void changePrice(String storeId, String menuId, int newPrice) throws SQLException {
        if (newPrice <= 0) throw new IllegalArgumentException("Price must be greater than 0");
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE menu SET price = ? WHERE menu_id = ? AND store_id = ?")) {
            ps.setInt(1, newPrice);
            ps.setString(2, menuId);
            ps.setString(3, storeId);
            if (ps.executeUpdate() == 0) throw new IllegalStateException("Menu item belongs to another store or does not exist");
            con.commit();
        }
    }

    /** Mark / unmark as sold out. Sold-out menu items cannot be ordered (OrderService.placeOrder). */
    public void setSoldOut(String storeId, String menuId, boolean soldOut) throws SQLException {
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE menu SET sold_out = ? WHERE menu_id = ? AND store_id = ?")) {
            ps.setBoolean(1, soldOut);
            ps.setString(2, menuId);
            ps.setString(3, storeId);
            ps.executeUpdate();
            con.commit();
        }
    }

    /** The store's menu on the customer screen — sold-out items are still listed, only marked as such. */
    public List<String[]> listMenu(String storeId) throws SQLException {
        List<String[]> rows = new ArrayList<>();
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT menu_id, menu_name, price, sold_out FROM menu WHERE store_id = ? ORDER BY menu_name")) {
            ps.setString(1, storeId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                rows.add(new String[] {rs.getString(1), rs.getString(2), String.valueOf(rs.getInt(3)),
                        rs.getBoolean(4) ? "Sold out" : "Available"});
            }
        }
        return rows;
    }
}
