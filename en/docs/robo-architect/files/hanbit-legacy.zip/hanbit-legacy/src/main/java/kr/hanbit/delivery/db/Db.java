package kr.hanbit.delivery.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** DB connection. Production settings come from system properties (unchanged since 2016). */
public final class Db {
    private Db() {}

    public static Connection open() throws SQLException {
        String url = System.getProperty("hanbit.db.url", "jdbc:postgresql://localhost:5432/hanbit?currentSchema=delivery");
        Connection con = DriverManager.getConnection(url, System.getProperty("hanbit.db.user", "hanbit"),
                System.getProperty("hanbit.db.password", ""));
        con.setAutoCommit(false);
        return con;
    }
}
