# Hanbit Delivery order system (since 2016)

The legacy order system used by store owners, customers and riders. Java 8 + JDBC; the DB is PostgreSQL (schema `delivery`).
Practice code for Chapter 13 (legacy code analysis) of the Robo Architect tutorial.
