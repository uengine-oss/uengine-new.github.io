---
name: hanbit-quote-format
description: Use whenever you write a quote or draft quote for a Hanbit Office customer. Defines the quote layout, the order of totals and the closing line.
---

# Hanbit Office quote format

Follow these rules every time you write a quote for a customer.

1. Start with the heading `Hanbit Office Quote — <customer name>`.
2. Put the items in one table with exactly these columns: Item | Qty | Unit price (KRW) | Discount | Amount (KRW).
3. Under the table, list in this order: Subtotal, Volume discount, Installation fee, Quote total (VAT excluded).
4. Take prices, discounts and fees only from the selected price list. If something is missing, say so instead of guessing.
5. End with exactly this line: `Valid for 30 days · Hanbit Office Sales Team`
