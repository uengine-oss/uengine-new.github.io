-- 한빛 딜리버리 기존 주문 시스템 DB (튜토리얼 실습용) — 스키마 delivery
CREATE SCHEMA IF NOT EXISTS delivery;
SET search_path = delivery;

CREATE TABLE store (
  store_id    varchar(10) PRIMARY KEY,
  store_name  varchar(60) NOT NULL,
  owner_name  varchar(30) NOT NULL,
  district    varchar(30) NOT NULL,
  is_open     boolean     NOT NULL DEFAULT true
);
CREATE TABLE menu (
  menu_id     varchar(10) PRIMARY KEY,
  store_id    varchar(10) NOT NULL REFERENCES store(store_id),
  menu_name   varchar(60) NOT NULL,
  price       integer     NOT NULL CHECK (price > 0),
  sold_out    boolean     NOT NULL DEFAULT false
);
CREATE TABLE customer (
  customer_id varchar(10) PRIMARY KEY,
  customer_name varchar(30) NOT NULL,
  phone       varchar(20) NOT NULL,
  address     varchar(100) NOT NULL
);
CREATE TABLE orders (
  order_id    varchar(12) PRIMARY KEY,
  customer_id varchar(10) NOT NULL REFERENCES customer(customer_id),
  store_id    varchar(10) NOT NULL REFERENCES store(store_id),
  status      varchar(20) NOT NULL,  -- WAITING, ACCEPTED, COOKING, DELIVERING, DELIVERED, CANCELLED, REJECTED
  total_price integer     NOT NULL,
  ordered_at  timestamp   NOT NULL
);
CREATE TABLE order_item (
  order_id    varchar(12) NOT NULL REFERENCES orders(order_id),
  menu_id     varchar(10) NOT NULL REFERENCES menu(menu_id),
  qty         integer     NOT NULL CHECK (qty > 0),
  unit_price  integer     NOT NULL,
  PRIMARY KEY (order_id, menu_id)
);
CREATE TABLE rider (
  rider_id    varchar(10) PRIMARY KEY,
  rider_name  varchar(30) NOT NULL,
  vehicle     varchar(20) NOT NULL
);
CREATE TABLE delivery (
  delivery_id varchar(12) PRIMARY KEY,
  order_id    varchar(12) NOT NULL REFERENCES orders(order_id),
  rider_id    varchar(10) REFERENCES rider(rider_id),
  picked_up_at timestamp,
  delivered_at timestamp
);

