# 한빛 딜리버리 주문 시스템 (2016~)

사장님 · 고객 · 라이더가 쓰는 기존 주문 시스템. Java 8 + JDBC, DB 는 PostgreSQL(스키마 `delivery`).
Robo Architect 튜토리얼 13장(레거시 코드 분석)의 실습용 코드다.
