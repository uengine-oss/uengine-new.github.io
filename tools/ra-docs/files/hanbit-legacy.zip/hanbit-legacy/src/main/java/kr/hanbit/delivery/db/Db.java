package kr.hanbit.delivery.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** DB 연결. 운영 설정은 시스템 프로퍼티로 받는다(2016 년 그대로). */
public final class Db {
    private Db() {}

    public static Connection open() throws SQLException {
        String url = System.getProperty("hanbit.db.url", "jdbc:postgresql://localhost:5432/hanbit?currentSchema=delivery");
        Connection con = DriverManager.getConnection(url, System.getProperty("hanbit.db.user", "hanbit"),
                System.getProperty("hanbit.db.password", ""));
        con.setAutoCommit(false);
        return con;
    }
}
