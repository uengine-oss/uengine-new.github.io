package kr.hanbit.delivery.order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Map;

import kr.hanbit.delivery.db.Db;

/**
 * 주문 처리. 상태: WAITING(접수 대기) → ACCEPTED(접수) → COOKING(조리 중) → DELIVERING → DELIVERED.
 * 접수 전에는 고객이 CANCELLED, 사장님이 REJECTED 로 끝낼 수 있다.
 */
public class OrderService {

    /**
     * 주문하기. 가게가 열려 있어야 하고, 품절 메뉴가 하나라도 있으면 주문 전체를 받지 않는다.
     * 가격은 주문 시점의 menu.price 를 order_item.unit_price 에 복사해 둔다(나중에 가격이 바뀌어도 그대로).
     */
    public String placeOrder(String customerId, String storeId, Map<String, Integer> menuQty) throws SQLException {
        if (menuQty == null || menuQty.isEmpty()) throw new IllegalArgumentException("주문할 메뉴가 없습니다");
        try (Connection con = Db.open()) {
            try (PreparedStatement st = con.prepareStatement("SELECT is_open FROM store WHERE store_id = ?")) {
                st.setString(1, storeId);
                ResultSet rs = st.executeQuery();
                if (!rs.next() || !rs.getBoolean(1)) throw new IllegalStateException("영업 중이 아닌 가게입니다");
            }
            String orderId = "O" + System.currentTimeMillis() % 100000000000L;
            int total = 0;
            try (PreparedStatement menu = con.prepareStatement(
                         "SELECT price, sold_out FROM menu WHERE menu_id = ? AND store_id = ?");
                 PreparedStatement item = con.prepareStatement(
                         "INSERT INTO order_item (order_id, menu_id, qty, unit_price) VALUES (?, ?, ?, ?)")) {
                for (Map.Entry<String, Integer> e : menuQty.entrySet()) {
                    if (e.getValue() == null || e.getValue() <= 0) throw new IllegalArgumentException("수량은 1 이상이어야 합니다");
                    menu.setString(1, e.getKey());
                    menu.setString(2, storeId);
                    ResultSet m = menu.executeQuery();
                    if (!m.next()) throw new IllegalArgumentException("이 가게의 메뉴가 아닙니다: " + e.getKey());
                    if (m.getBoolean("sold_out")) throw new IllegalStateException("품절 메뉴가 있습니다: " + e.getKey());
                    int price = m.getInt("price");
                    total += price * e.getValue();
                    item.setString(1, orderId);
                    item.setString(2, e.getKey());
                    item.setInt(3, e.getValue());
                    item.setInt(4, price);
                    item.addBatch();
                }
                try (PreparedStatement ord = con.prepareStatement(
                        "INSERT INTO orders (order_id, customer_id, store_id, status, total_price, ordered_at) VALUES (?, ?, ?, 'WAITING', ?, ?)")) {
                    ord.setString(1, orderId);
                    ord.setString(2, customerId);
                    ord.setString(3, storeId);
                    ord.setInt(4, total);
                    ord.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
                    ord.executeUpdate();
                }
                item.executeBatch();
            }
            con.commit();
            return orderId;
        }
    }

    /** 사장님 접수. 접수 대기(WAITING) 주문만. 동시에 고객이 취소하면 한쪽만 성공한다(조건부 UPDATE). */
    public void acceptOrder(String storeId, String orderId) throws SQLException {
        changeStatus(storeId, orderId, "WAITING", "ACCEPTED", "접수 대기 주문만 접수할 수 있습니다");
    }

    /** 사장님 거절(재료 소진 등). 사유는 따로 남기지 않는다 — 고객에게는 전화로 알린다. */
    public void rejectOrder(String storeId, String orderId) throws SQLException {
        changeStatus(storeId, orderId, "WAITING", "REJECTED", "접수 대기 주문만 거절할 수 있습니다");
    }

    /** 조리 시작. */
    public void startCooking(String storeId, String orderId) throws SQLException {
        changeStatus(storeId, orderId, "ACCEPTED", "COOKING", "접수된 주문만 조리를 시작할 수 있습니다");
    }

    /** 고객 취소. 자기 주문이고 아직 접수 전(WAITING)일 때만. */
    public void cancelOrder(String customerId, String orderId) throws SQLException {
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE orders SET status = 'CANCELLED' WHERE order_id = ? AND customer_id = ? AND status = 'WAITING'")) {
            ps.setString(1, orderId);
            ps.setString(2, customerId);
            if (ps.executeUpdate() == 0) throw new IllegalStateException("이미 접수된 주문은 취소할 수 없습니다");
            con.commit();
        }
    }

    private void changeStatus(String storeId, String orderId, String from, String to, String message) throws SQLException {
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE orders SET status = ? WHERE order_id = ? AND store_id = ? AND status = ?")) {
            ps.setString(1, to);
            ps.setString(2, orderId);
            ps.setString(3, storeId);
            ps.setString(4, from);
            if (ps.executeUpdate() == 0) throw new IllegalStateException(message);
            con.commit();
        }
    }
}
