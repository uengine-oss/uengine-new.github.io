package kr.hanbit.delivery.report;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

import kr.hanbit.delivery.db.Db;

/** 가게별 일 정산. 배달 완료(DELIVERED) 주문만 매출로 친다. 수수료 3%(2018 계약). */
public class SettlementReport {
    static final double FEE_RATE = 0.03;

    public Map<String, int[]> daily(Date day) throws SQLException {
        Map<String, int[]> result = new LinkedHashMap<>();
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT s.store_name, COUNT(*), SUM(o.total_price) FROM orders o JOIN store s ON s.store_id = o.store_id "
                             + "WHERE o.status = 'DELIVERED' AND CAST(o.ordered_at AS date) = ? GROUP BY s.store_name ORDER BY s.store_name")) {
            ps.setDate(1, day);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int sales = rs.getInt(3);
                int fee = (int) Math.round(sales * FEE_RATE);
                result.put(rs.getString(1), new int[] {rs.getInt(2), sales, fee, sales - fee});
            }
        }
        return result;
    }
}
