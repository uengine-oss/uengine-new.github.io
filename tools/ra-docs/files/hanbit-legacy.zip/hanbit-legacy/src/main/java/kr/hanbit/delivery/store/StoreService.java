package kr.hanbit.delivery.store;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import kr.hanbit.delivery.db.Db;

/** 가게 영업 상태. */
public class StoreService {

    public void open(String storeId) throws SQLException {
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement("UPDATE store SET is_open = true WHERE store_id = ?")) {
            ps.setString(1, storeId);
            ps.executeUpdate();
            con.commit();
        }
    }

    /** 영업 종료. 아직 접수하지 않은(WAITING) 주문은 모두 거절(REJECTED)로 끝낸다. */
    public int close(String storeId) throws SQLException {
        try (Connection con = Db.open();
             PreparedStatement st = con.prepareStatement("UPDATE store SET is_open = false WHERE store_id = ?");
             PreparedStatement rej = con.prepareStatement(
                     "UPDATE orders SET status = 'REJECTED' WHERE store_id = ? AND status = 'WAITING'")) {
            st.setString(1, storeId);
            st.executeUpdate();
            rej.setString(1, storeId);
            int rejected = rej.executeUpdate();
            con.commit();
            return rejected;
        }
    }
}
