package kr.hanbit.delivery.menu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import kr.hanbit.delivery.db.Db;

/** 사장님의 메뉴 관리 — 등록, 가격 변경, 품절 처리. */
public class MenuService {

    /** 메뉴 등록. 가격은 0원보다 커야 하고, 같은 가게에 같은 이름의 메뉴는 둘 수 없다. */
    public String registerMenu(String storeId, String menuName, int price) throws SQLException {
        if (menuName == null || menuName.trim().isEmpty()) throw new IllegalArgumentException("메뉴 이름이 비었습니다");
        if (price <= 0) throw new IllegalArgumentException("가격은 0원보다 커야 합니다");
        try (Connection con = Db.open()) {
            try (PreparedStatement dup = con.prepareStatement(
                    "SELECT 1 FROM menu WHERE store_id = ? AND menu_name = ?")) {
                dup.setString(1, storeId);
                dup.setString(2, menuName.trim());
                if (dup.executeQuery().next()) throw new IllegalStateException("이미 있는 메뉴 이름입니다");
            }
            String menuId = "M" + System.currentTimeMillis() % 100000000;
            try (PreparedStatement ins = con.prepareStatement(
                    "INSERT INTO menu (menu_id, store_id, menu_name, price, sold_out) VALUES (?, ?, ?, ?, false)")) {
                ins.setString(1, menuId);
                ins.setString(2, storeId);
                ins.setString(3, menuName.trim());
                ins.setInt(4, price);
                ins.executeUpdate();
            }
            con.commit();
            return menuId;
        }
    }

    /** 가격 변경. 이미 받은 주문의 금액은 order_item.unit_price 에 남아 있어 바뀌지 않는다. */
    public void changePrice(String storeId, String menuId, int newPrice) throws SQLException {
        if (newPrice <= 0) throw new IllegalArgumentException("가격은 0원보다 커야 합니다");
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE menu SET price = ? WHERE menu_id = ? AND store_id = ?")) {
            ps.setInt(1, newPrice);
            ps.setString(2, menuId);
            ps.setString(3, storeId);
            if (ps.executeUpdate() == 0) throw new IllegalStateException("다른 가게의 메뉴이거나 없는 메뉴입니다");
            con.commit();
        }
    }

    /** 품절 표시 / 해제. 품절 메뉴는 주문할 수 없다(OrderService.placeOrder). */
    public void setSoldOut(String storeId, String menuId, boolean soldOut) throws SQLException {
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE menu SET sold_out = ? WHERE menu_id = ? AND store_id = ?")) {
            ps.setBoolean(1, soldOut);
            ps.setString(2, menuId);
            ps.setString(3, storeId);
            ps.executeUpdate();
            con.commit();
        }
    }

    /** 고객 화면의 가게 메뉴 — 품절도 보이되 표시만 한다. */
    public List<String[]> listMenu(String storeId) throws SQLException {
        List<String[]> rows = new ArrayList<>();
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement(
                     "SELECT menu_id, menu_name, price, sold_out FROM menu WHERE store_id = ? ORDER BY menu_name")) {
            ps.setString(1, storeId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                rows.add(new String[] {rs.getString(1), rs.getString(2), String.valueOf(rs.getInt(3)),
                        rs.getBoolean(4) ? "품절" : "판매중"});
            }
        }
        return rows;
    }
}
