package kr.hanbit.delivery.delivery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

import kr.hanbit.delivery.db.Db;

/** 배달 — 라이더 배정, 픽업, 배달 완료. */
public class DeliveryService {

    /** 조리 중(COOKING) 주문에 라이더를 배정하고 배달 중(DELIVERING)으로 바꾼다. 한 주문에 배달은 하나. */
    public String dispatch(String orderId, String riderId) throws SQLException {
        try (Connection con = Db.open()) {
            try (PreparedStatement chk = con.prepareStatement("SELECT 1 FROM delivery WHERE order_id = ?")) {
                chk.setString(1, orderId);
                if (chk.executeQuery().next()) throw new IllegalStateException("이미 배달이 배정된 주문입니다");
            }
            try (PreparedStatement up = con.prepareStatement(
                    "UPDATE orders SET status = 'DELIVERING' WHERE order_id = ? AND status = 'COOKING'")) {
                up.setString(1, orderId);
                if (up.executeUpdate() == 0) throw new IllegalStateException("조리 중인 주문만 배달할 수 있습니다");
            }
            String deliveryId = "D" + System.currentTimeMillis() % 100000000000L;
            try (PreparedStatement ins = con.prepareStatement(
                    "INSERT INTO delivery (delivery_id, order_id, rider_id) VALUES (?, ?, ?)")) {
                ins.setString(1, deliveryId);
                ins.setString(2, orderId);
                ins.setString(3, riderId);
                ins.executeUpdate();
            }
            con.commit();
            return deliveryId;
        }
    }

    /** 라이더가 가게에서 음식을 받음. */
    public void pickUp(String deliveryId, String riderId) throws SQLException {
        try (Connection con = Db.open();
             PreparedStatement ps = con.prepareStatement(
                     "UPDATE delivery SET picked_up_at = ? WHERE delivery_id = ? AND rider_id = ? AND picked_up_at IS NULL")) {
            ps.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
            ps.setString(2, deliveryId);
            ps.setString(3, riderId);
            if (ps.executeUpdate() == 0) throw new IllegalStateException("배정된 라이더가 아니거나 이미 픽업했습니다");
            con.commit();
        }
    }

    /** 배달 완료 — 픽업한 배달만. 주문도 DELIVERED 로. */
    public void complete(String deliveryId, String riderId) throws SQLException {
        try (Connection con = Db.open()) {
            String orderId;
            try (PreparedStatement q = con.prepareStatement(
                    "SELECT order_id FROM delivery WHERE delivery_id = ? AND rider_id = ? AND picked_up_at IS NOT NULL AND delivered_at IS NULL")) {
                q.setString(1, deliveryId);
                q.setString(2, riderId);
                ResultSet rs = q.executeQuery();
                if (!rs.next()) throw new IllegalStateException("픽업하지 않았거나 이미 완료된 배달입니다");
                orderId = rs.getString(1);
            }
            try (PreparedStatement d = con.prepareStatement("UPDATE delivery SET delivered_at = ? WHERE delivery_id = ?");
                 PreparedStatement o = con.prepareStatement("UPDATE orders SET status = 'DELIVERED' WHERE order_id = ?")) {
                d.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
                d.setString(2, deliveryId);
                d.executeUpdate();
                o.setString(1, orderId);
                o.executeUpdate();
            }
            con.commit();
        }
    }
}
